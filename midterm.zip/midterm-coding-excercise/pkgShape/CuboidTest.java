package pkgShape;

import static org.junit.Assert.*;

import org.junit.Test;

public class CuboidTest {

	
	@Test
	public void getiDepthtest() {
		Cuboid testCuboid= new Cuboid(10,20,30);
		int result= testCuboid.iDepth;
		assertEquals(30, result);
	}
	
	@Test
	public void setiDepthtest() {
		Cuboid testCuboid= new Cuboid(10,20,30);
		testCuboid.setiDepth(40);
		int result= testCuboid.iDepth;
		assertEquals(40, result);
	}
	
	@Test
	public void volumetest() {
		Cuboid testCuboid= new Cuboid(10,20,30);
		double result= testCuboid.volume();
		assertEquals(6000, result, 0.001);
	}
	
	@Test
	public void areatest() {
		Cuboid testCuboid= new Cuboid(10,20,30);
		double result= testCuboid.area();
		assertEquals(2200, result, 0.001);
	}
	

}
