package pkgShape;

public class Rectangle extends Shape {
	protected int iWidth;
	
	protected int iLength;
	
	public Rectangle() {};
	
	public Rectangle(int x, int y){
		this.iWidth=y;
		this.iLength=x;
		
	}
	
	public int getiWidth() {
		return(this.iWidth);
	}
	
	public void setiWidth(int x) {
		this.iWidth=x;
		
	}
	
	public int getiLength() {
		return(this.iLength);
	}
	;
	public void setiLength(int x) {
		this.iLength=x;
	}
	
	
	public double area() {
		return(iWidth*iLength);
	};
	
	public double perimeter() {
		return((2*iWidth)+(2*iLength));
	};
	
	public int compareTo(Rectangle rectangle) {
		
		return (this.area() > rectangle.area() ? 1 : this.area() < rectangle.area() ? -1 : 0);
		
		
	}
	

}
