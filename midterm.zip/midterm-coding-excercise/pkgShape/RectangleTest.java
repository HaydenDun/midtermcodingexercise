package pkgShape;

import static org.junit.Assert.*;

import org.junit.Test;

public class RectangleTest {
	
	
	
	@Test
	public void getiLengthtest() {
		Rectangle testRectangle= new Rectangle(10,50);
		int result= testRectangle.getiLength();
		assertEquals(10, result);
		
		
	}
	
	
	@Test
	public void setiLengthtest() {
		Rectangle testRectangle= new Rectangle(10,50);
		testRectangle.setiLength(20);
		int result = testRectangle.getiLength();
		assertEquals(20, result);
		
		
	}
	
	
	@Test
	public void setiWidthtest() {
		Rectangle testRectangle= new Rectangle(10,50);
		testRectangle.setiWidth(30);
		int result = testRectangle.getiWidth();
		assertEquals(30, result);
		
		
		
	}

	@Test
	public void getiWidthtest() {
		Rectangle testRectangle= new Rectangle(10,50);
		int result = testRectangle.getiWidth();
		assertEquals(50, result);
		
		
	}
	
	
	@Test
	public void areatest() {
		Rectangle testRectangle= new Rectangle(10,50);
		double result= testRectangle.area();
		assertEquals(500,result,0.01);
	}
	
	
	@Test
	public void perimetertest() {
		Rectangle testRectangle= new Rectangle(10,50);
		double result= testRectangle.perimeter();
		assertEquals(120,result,0.01);
	}
	
	@Test
	public void compareTotest() {
		Rectangle testRectangle= new Rectangle(10,50);
		Rectangle testRectangle2= new Rectangle(20,50);
		int result= testRectangle.compareTo(testRectangle2);
		assertEquals(-1,result,0.01);
	}
	
	
	
	

}
