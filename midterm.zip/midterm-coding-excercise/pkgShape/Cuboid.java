package pkgShape;


public class Cuboid extends Rectangle {
	protected int iDepth;
	
	public Cuboid(int x, int y, int z) {
		this.iLength=x;
		this.iWidth=y;
		this.iDepth=z;	
		
	}

	public int getiDepth() {
		return(this.iDepth);
	}
	
	public void setiDepth(int x) {
		this.iDepth=x;
	}
	
	public double volume() {
		return(iLength*iWidth*iDepth);
	}
	
	
	@Override
	public double area() {
		return (2*(this.iLength*this.iDepth))+(2*(this.iWidth*this.iDepth))+(2*(this.iLength*this.iWidth));
	}
	

	
	
	
	
	
	
}
